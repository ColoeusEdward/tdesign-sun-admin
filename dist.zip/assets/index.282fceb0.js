import{r as W,q as aa,X as ra,d as t,z as e,j as d,A as ea,a as l}from"./index.03bc2e41.js";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var da={bordered:!0,headerBordered:!1,hoverShadow:!1,loading:!1,shadow:!1,size:"medium",theme:"normal"};/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var p=W.exports.forwardRef(function(a,C){var o,n,c=a.actions,v=a.avatar,N=a.bordered,b=a.children,z=a.className,s=a.cover,_=a.description,f=a.footer,k=a.header,P=a.headerBordered,S=a.hoverShadow,j=a.loading,A=a.shadow,B=a.size,H=a.style,h=a.subtitle,m=a.title,D=a.theme,x=a.status,F=aa(),r=F.classPrefix,M=ra(),i=D==="poster2",g=t("".concat(r,"-card"),z,(o={},e(o,M.SIZE.small,B==="small"),e(o,"".concat(r,"-card--bordered"),N),e(o,"".concat(r,"--shadow"),A),e(o,"".concat(r,"-card--shadow-hover"),S),o)),u=k||m||h||_||v||c&&!i||x&&i,q=t((n={},e(n,"".concat(r,"-card__header"),u),e(n,"".concat(r,"-card__title--bordered"),P),n)),E=t(e({},"".concat(r,"-card__title"),m)),I=t(e({},"".concat(r,"-card__subtitle"),h)),w=t(e({},"".concat(r,"-card__actions"),c)),L=t(e({},"".concat(r,"-card__footer"),f)),R=t(e({},"".concat(r,"-card__cover"),s)),T=t(e({},"".concat(r,"-card__avatar"),v)),X=t(e({},"".concat(r,"-card__body"),b)),Y=t(e({},"".concat(r,"-card__description"),_)),Z=m?d("span",{className:E,children:m}):null,$=h?d("span",{className:I,children:h}):null,G=_?d("p",{className:Y,children:_}):null,J=v&&d("div",{className:T,children:v}),y=c&&!i&&d("div",{className:w,children:c}),K=x&&i&&d("div",{className:w,children:x}),O=u&&l("div",{className:q,children:[l("div",{className:"".concat(r,"-card__header-wrapper"),children:[J,l("div",{children:[Z,$,G]})]}),y,K]}),Q=s?d("div",{className:R,children:typeof s=="string"?d("img",{src:s,alt:""}):s}):null,U=b&&d("div",{className:X,children:b}),V=f&&l("div",{className:L,children:[d("div",{className:"".concat(r,"-card__footer-wrapper"),children:f}),i&&c&&y]});return j?d(ea,{children:d("div",{className:g})}):l("div",{ref:C,className:g,style:H,children:[O,Q,U,V]})});p.displayName="Card";p.defaultProps=da;/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var oa=p;export{oa as C};
