const a="_pageWithPadding_1t34a_1",t="_pageWithColor_1t34a_4";var o={pageWithPadding:a,pageWithColor:t};export{o as C};
