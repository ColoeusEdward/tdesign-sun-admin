import{r as W,o as aa,X as ea,c as d,x as r,j as t,y as ra,a as l}from"./index.bf91dbec.js";/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var ta={bordered:!0,headerBordered:!1,hoverShadow:!1,loading:!1,shadow:!1,size:"medium",theme:"normal"};/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var w=W.exports.forwardRef(function(a,k){var o,n,s=a.actions,b=a.avatar,C=a.bordered,h=a.children,N=a.className,i=a.cover,v=a.description,m=a.footer,z=a.header,j=a.headerBordered,P=a.hoverShadow,S=a.loading,A=a.shadow,B=a.size,H=a.style,x=a.subtitle,_=a.title,D=a.theme,f=a.status,F=aa(),e=F.classPrefix,M=ea(),c=D==="poster2",p=d(N,"".concat(e,"-card"),(o={},r(o,M.SIZE.small,B==="small"),r(o,"".concat(e,"-card--bordered"),C),r(o,"".concat(e,"--shadow"),A),r(o,"".concat(e,"-card--shadow-hover"),P),o)),u=z||_||x||v||b||s&&!c||f&&c,E=d((n={},r(n,"".concat(e,"-card__header"),u),r(n,"".concat(e,"-card__title--bordered"),j),n)),I=d(r({},"".concat(e,"-card__title"),_)),L=d(r({},"".concat(e,"-card__subtitle"),x)),y=d(r({},"".concat(e,"-card__actions"),s)),R=d(r({},"".concat(e,"-card__footer"),m)),T=d(r({},"".concat(e,"-card__cover"),i)),X=d(r({},"".concat(e,"-card__avatar"),b)),Y=d(r({},"".concat(e,"-card__body"),h)),Z=d(r({},"".concat(e,"-card__description"),v)),$=_?t("span",{className:I,children:_}):null,q=x?t("span",{className:L,children:x}):null,G=v?t("p",{className:Z,children:v}):null,J=b&&t("div",{className:X,children:b}),g=s&&!c&&t("div",{className:y,children:s}),K=f&&c&&t("div",{className:y,children:f}),O=u&&l("div",{className:E,children:[l("div",{className:"".concat(e,"-card__header-wrapper"),children:[J,l("div",{children:[$,q,G]})]}),g,K]}),Q=i?t("div",{className:T,children:typeof i=="string"?t("img",{src:i,alt:""}):i}):null,U=h&&t("div",{className:Y,children:h}),V=m&&l("div",{className:R,children:[t("div",{className:"".concat(e,"-card__footer-wrapper"),children:m}),c&&s&&g]});return S?t(ra,{children:t("div",{className:p})}):l("div",{ref:k,className:p,style:H,children:[O,Q,U,V]})});w.displayName="Card";w.defaultProps=ta;/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var oa=w;export{oa as C};
