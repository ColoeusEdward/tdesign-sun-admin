import{D as o}from"./dep-33f486c3.8fa5c456.js";import"./index.bf91dbec.js";/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var i=o;export{i as D};
