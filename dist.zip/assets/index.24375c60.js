import{r as z,q as p,j as n,d as f,a as x,au as J,v as K,w as O,ak as Q,R as o,z as c,A as U,an as w}from"./index.03bc2e41.js";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var E=z.exports.forwardRef(function(t,m){var l=t.children,i=t.className,s=t.action,d=t.content,e=p(),r=e.classPrefix,_=s&&n("ul",{className:"".concat(r,"-list-item__action"),children:s});return n("li",{ref:m,className:f("".concat(r,"-list-item"),i),children:x("div",{className:"".concat(r,"-list-item-main"),children:[l||d,_]})})});E.displayName="ListItem";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var P=z.exports.forwardRef(function(t,m){var l=t.title,i=t.image,s=t.description,d=p(),e=d.classPrefix,r=function(){return i&&typeof i=="string"?n("div",{className:"".concat(e,"-list-item__meta-avatar"),children:n("img",{src:i,alt:""})}):n("div",{className:"".concat(e,"-list-item__meta-avatar"),children:i})};return x("div",{ref:m,className:"".concat(e,"-list-item__meta"),children:[i&&r(),x("div",{className:"".concat(e,"-list-item__meta-content"),children:[n("h3",{className:"".concat(e,"-list-item__meta-title"),children:l}),n("div",{className:"".concat(e,"-list-item__meta-description"),children:n("p",{children:s})})]})]})});P.displayName="ListItemMeta";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var V={layout:"horizontal",size:"medium",split:!1,stripe:!1};/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var h=J(function(t,m){var l,i,s=t.header,d=t.footer,e=t.asyncLoading,r=t.size,_=t.split,R=t.stripe,S=t.layout,T=t.children,C=t.className,u=t.onLoadMore,M=u===void 0?w:u,y=t.onScroll,j=y===void 0?w:y,I=t.style,A=p(),a=A.classPrefix,H=K("list"),N=O(H,2),L=N[0],b=N[1],$=function(g){e==="load-more"&&M({e:g})},B=function(g){var v=g.currentTarget,k=v.scrollTop,W=v.offsetHeight,F=v.scrollHeight,G=F-k-W;j({e:g,scrollTop:k,scrollBottom:G})},q=Q(e)?o.createElement("div",{className:f("".concat(a,"-list__load"),(l={},c(l,"".concat(a,"-list__load--loading"),e==="loading"),c(l,"".concat(a,"-list__load--load-more"),e==="load-more"),l)),onClick:$},e==="loading"&&o.createElement("div",null,o.createElement(U,{loading:!0}),o.createElement("span",null,b(L.loadingText))),e==="load-more"&&o.createElement("span",null,b(L.loadingMoreText))):e;return o.createElement("div",{ref:m,style:I,onScroll:B,className:f("".concat(a,"-list"),C,(i={},c(i,"".concat(a,"-list--split"),_),c(i,"".concat(a,"-list--stripe"),R),c(i,"".concat(a,"-list--vertical-action"),S==="vertical"),c(i,"".concat(a,"-size-s"),r==="small"),c(i,"".concat(a,"-size-l"),r==="large"),i))},s&&o.createElement("div",{className:"".concat(a,"-list__header")},s),o.createElement("ul",{className:"".concat(a,"-list__inner")},T),e&&q,d&&o.createElement("div",{className:"".concat(a,"-list__footer")},d))},{ListItem:E,ListItemMeta:P});h.displayName="List";h.defaultProps=V;/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var Y=h;export{Y as L};
