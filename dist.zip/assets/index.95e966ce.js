import{D as o}from"./formModel.2b65d27f.js";import"./index.03bc2e41.js";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var i=o;export{i as D};
