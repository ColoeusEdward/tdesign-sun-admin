import{T as o}from"./Tooltip.b9773c00.js";import"./index.03bc2e41.js";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var t=o;export{t as T};
