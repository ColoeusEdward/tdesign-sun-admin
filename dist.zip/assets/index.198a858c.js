var ye=Object.defineProperty;var G=Object.getOwnPropertySymbols;var we=Object.prototype.hasOwnProperty,Oe=Object.prototype.propertyIsEnumerable;var Q=(e,r,t)=>r in e?ye(e,r,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[r]=t,ee=(e,r)=>{for(var t in r||(r={}))we.call(r,t)&&Q(e,t,r[t]);if(G)for(var t of G(r))Oe.call(r,t)&&Q(e,t,r[t]);return e};import{bf as Se,r as l,aw as ze,x as je,w as T,aJ as te,W as K,q as Pe,z as v,d as I,a as M,j as re,an as D}from"./index.03bc2e41.js";/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var Te=`
  min-height:0 !important;
  max-height:none !important;
  height:0 !important;
  visibility:hidden !important;
  overflow:hidden !important;
  position:absolute !important;
  z-index:-1000 !important;
  top:0 !important;
  right:0 !important
`,d;function ae(e){var r,t,n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1,f=arguments.length>2&&arguments[2]!==void 0?arguments[2]:null;d||(d=document.createElement("textarea"),document.body.appendChild(d));var u=Se(e),i=u.paddingSize,_=u.borderSize,O=u.boxSizing,N=u.sizingStyle;d.setAttribute("style","".concat(N,";").concat(Te)),d.value=e.value||e.placeholder||"";var x=d.scrollHeight,b={},S=O==="border-box",z=O==="content-box";S?x+=_:z&&(x-=i),d.value="";var C=d.scrollHeight-i;(r=d)===null||r===void 0||(t=r.parentNode)===null||t===void 0||t.removeChild(d),d=null;var y=function(h){var m=C*h;return S&&(m=m+i+_),m};if(n!==null){var j=y(n);x=Math.max(j,x),b.minHeight="".concat(j,"px")}return f!==null&&(x=Math.min(y(f),x)),b.height="".concat(x,"px"),b}/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var Ke={allowInputOverMax:!1,autofocus:!1,autosize:!1,disabled:!1,placeholder:void 0,readonly:!1};/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var Ne=["disabled","maxlength","maxcharacter","className","readonly","autofocus","style","onKeydown","onKeypress","onKeyup","autosize","status","tips","allowInputOverMax"];function oe(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);r&&(n=n.filter(function(f){return Object.getOwnPropertyDescriptor(e,f).enumerable})),t.push.apply(t,n)}return t}function L(e){for(var r=1;r<arguments.length;r++){var t=arguments[r]!=null?arguments[r]:{};r%2?oe(Object(t),!0).forEach(function(n){v(e,n,t[n])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):oe(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})}return e}var A=l.exports.forwardRef(function(e,r){var t,n,f=e.disabled,u=e.maxlength,i=e.maxcharacter,_=e.className,O=e.readonly,N=e.autofocus,x=e.style,b=e.onKeydown,S=b===void 0?D:b,z=e.onKeypress,C=z===void 0?D:z,y=e.onKeyup,j=y===void 0?D:y,s=e.autosize,h=e.status,m=e.tips,w=e.allowInputOverMax,$=ze(e,Ne),ne=je(e,"value",e.onChange),F=T(ne,2),k=F[0],g=k===void 0?"":k,ie=F[1],se=l.exports.useState(!1),B=T(se,2),le=B[0],U=B[1],ce=l.exports.useState(!1),V=T(ce,2),de=V[0],ue=V[1],xe=l.exports.useState({}),W=T(xe,2),ve=W[0],R=W[1],Z=typeof i!="undefined",P=l.exports.useRef(),q=l.exports.useRef(),J=l.exports.useMemo(function(){return g?String(g).length:0},[g]),H=l.exports.useMemo(function(){var o=te(String(g),w?1/0:i);return K(o)==="object"?o.length:o},[g,w,i]),fe=Pe(),c=fe.classPrefix,pe=Object.keys($).filter(function(o){return!/^on[A-Z]/.test(o)}),he=pe.reduce(function(o,a){return Object.assign(o,v({},a,e[a]))},{}),ge=Object.keys($).filter(function(o){return/^on[A-Z]/.test(o)}),be=ge.reduce(function(o,a){return Object.assign(o,v({},a,function(p){f||(a==="onFocus"&&U(!0),a==="onBlur"&&U(!1),e[a](p.currentTarget.value,{e:p}))})),o},{}),me=I("".concat(c,"-textarea__inner"),_,(t={},v(t,"".concat(c,"-is-").concat(h),h),v(t,"".concat(c,"-is-disabled"),f),v(t,"".concat(c,"-is-focused"),le),v(t,"".concat(c,"-resize-none"),K(s)==="object"),t)),E=l.exports.useCallback(function(){s===!0?R(ae(P.current)):K(s)==="object"&&R(ae(P.current,s==null?void 0:s.minRows,s==null?void 0:s.maxRows))},[s]);function _e(o){var a=o.target,p=a.value;if(!w&&i&&i>=0){var Y=te(p,i);p=K(Y)==="object"&&Y.characters}ie(p,{e:o})}var X=function(a,p){return M("span",{className:"".concat(c,"-textarea__limit"),children:[de?M("span",{className:"".concat(c,"-textarea__tips--warning"),children:[" ",a]}):"".concat(a),"/".concat(p)]})};return l.exports.useEffect(function(){s===!1&&R({height:"auto",minHeight:"auto"})},[E,s]),l.exports.useEffect(function(){E()},[E,g]),l.exports.useEffect(function(){w&&ue(!!(u&&J>u)||!!(i&&H>i))},[H]),l.exports.useImperativeHandle(r,function(){return{currentElement:q.current,textareaElement:P.current}}),M("div",{style:x,ref:q,className:I("".concat(c,"-textarea"),_),children:[re("textarea",ee({},L(L(L({},he),be),{},{value:g,style:ve,className:me,readOnly:O,autoFocus:N,disabled:f,maxLength:w?1/0:u,onChange:_e,onKeyDown:function(a){return S(a.currentTarget.value,{e:a})},onKeyPress:function(a){return C(a.currentTarget.value,{e:a})},onKeyUp:function(a){return j(a.currentTarget.value,{e:a})},ref:P}))),Z&&X(H,i),!Z&&u&&X(J,u),m?re("div",{className:I("".concat(c,"-textarea__tips"),(n={},v(n,"".concat(c,"-textarea__tips--normal"),!h),v(n,"".concat(c,"-textarea__tips--").concat(h),h),n)),children:m}):null]})});A.displayName="Textarea";A.defaultProps=Ke;/**
 * tdesign v0.35.0
 * (c) 2022 tdesign
 * @license MIT
 */var He=A;export{He as T};
