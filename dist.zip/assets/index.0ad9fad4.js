import{R as r,j as o}from"./index.03bc2e41.js";import{E as e}from"./index.7dcb2315.js";const a=()=>o(e,{code:500});var t=r.memo(a);export{t as default};
