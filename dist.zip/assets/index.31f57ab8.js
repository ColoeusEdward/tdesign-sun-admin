import{r as z,o as v,j as n,c as g,a as p,as as J,p as K,q as O,ai as Q,R as o,x as c,y as U,al as L}from"./index.bf91dbec.js";/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var E=z.exports.forwardRef(function(t,m){var l=t.children,i=t.className,r=t.action,d=t.content,e=v(),s=e.classPrefix,x=r&&n("ul",{className:"".concat(s,"-list-item__action"),children:r});return n("li",{ref:m,className:g(i,"".concat(s,"-list-item")),children:p("div",{className:"".concat(s,"-list-item-main"),children:[l||d,x]})})});E.displayName="ListItem";/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var j=z.exports.forwardRef(function(t,m){var l=t.title,i=t.image,r=t.description,d=v(),e=d.classPrefix,s=function(){return i&&typeof i=="string"?n("div",{className:"".concat(e,"-list-item__meta-avatar"),children:n("img",{src:i,alt:""})}):n("div",{className:"".concat(e,"-list-item__meta-avatar"),children:i})};return p("div",{ref:m,className:"".concat(e,"-list-item__meta"),children:[i&&s(),p("div",{className:"".concat(e,"-list-item__meta-content"),children:[n("h3",{className:"".concat(e,"-list-item__meta-title"),children:l}),n("div",{className:"".concat(e,"-list-item__meta-description"),children:n("p",{children:r})})]})]})});j.displayName="ListItemMeta";/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var V={layout:"horizontal",size:"medium",split:!1,stripe:!1};/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var h=J(function(t,m){var l,i,r=t.header,d=t.footer,e=t.asyncLoading,s=t.size,x=t.split,P=t.stripe,R=t.layout,S=t.children,T=t.className,u=t.onLoadMore,C=u===void 0?L:u,b=t.onScroll,M=b===void 0?L:b,I=t.style,H=v(),a=H.classPrefix,A=K("list"),y=O(A,2),k=y[0],w=y[1],$=function(f){e==="load-more"&&C({e:f})},B=function(f){var _=f.currentTarget,N=_.scrollTop,W=_.offsetHeight,F=_.scrollHeight,G=F-N-W;M({e:f,scrollTop:N,scrollBottom:G})},q=Q(e)?o.createElement("div",{className:g("".concat(a,"-list__load"),(l={},c(l,"".concat(a,"-list__load--loading"),e==="loading"),c(l,"".concat(a,"-list__load--load-more"),e==="load-more"),l)),onClick:$},e==="loading"&&o.createElement("div",null,o.createElement(U,{loading:!0}),o.createElement("span",null,w(k.loadingText))),e==="load-more"&&o.createElement("span",null,w(k.loadingMoreText))):e;return o.createElement("div",{ref:m,style:I,onScroll:B,className:g(T,"t-list",(i={},c(i,"".concat(a,"-list--split"),x),c(i,"".concat(a,"-list--stripe"),P),c(i,"".concat(a,"-list--vertical-action"),R==="vertical"),c(i,"".concat(a,"-size-s"),s==="small"),c(i,"".concat(a,"-size-l"),s==="large"),i))},r&&o.createElement("div",{className:"".concat(a,"-list__header")},r),o.createElement("ul",{className:"".concat(a,"-list__inner")},S),e&&q,d&&o.createElement("div",{className:"".concat(a,"-list__footer")},d))},{ListItem:E,ListItemMeta:j});h.displayName="List";h.defaultProps=V;/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var Y=h;export{Y as L};
