var ve=Object.defineProperty;var Z=Object.getOwnPropertySymbols;var he=Object.prototype.hasOwnProperty,fe=Object.prototype.propertyIsEnumerable;var q=(e,r,t)=>r in e?ve(e,r,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[r]=t,G=(e,r)=>{for(var t in r||(r={}))he.call(r,t)&&q(e,t,r[t]);if(Z)for(var t of Z(r))fe.call(r,t)&&q(e,t,r[t]);return e};import{bl as be,r as c,au as ge,v as me,q as H,W as X,G as P,o as _e,x,c as k,a as ye,j as K,al as E}from"./index.bf91dbec.js";/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var we=`
  min-height:0 !important;
  max-height:none !important;
  height:0 !important;
  visibility:hidden !important;
  overflow:hidden !important;
  position:absolute !important;
  z-index:-1000 !important;
  top:0 !important;
  right:0 !important
`,d;function Y(e){var r,t,n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1,p=arguments.length>2&&arguments[2]!==void 0?arguments[2]:null;d||(d=document.createElement("textarea"),document.body.appendChild(d));var v=be(e),s=v.paddingSize,_=v.borderSize,w=v.boxSizing,N=v.sizingStyle;d.setAttribute("style","".concat(N,";").concat(we)),d.value=e.value||e.placeholder||"";var u=d.scrollHeight,b={},z=w==="border-box",S=w==="content-box";z?u+=_:S&&(u-=s),d.value="";var T=d.scrollHeight-s;(r=d)===null||r===void 0||(t=r.parentNode)===null||t===void 0||t.removeChild(d),d=null;var y=function(h){var g=T*h;return z&&(g=g+s+_),g};if(n!==null){var j=y(n);u=Math.max(j,u),b.minHeight="".concat(j,"px")}return p!==null&&(u=Math.min(y(p),u)),b.height="".concat(u,"px"),b}/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var ze={autofocus:!1,autosize:!1,disabled:!1,placeholder:void 0,readonly:!1};/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var Se=["disabled","maxlength","maxcharacter","className","readonly","autofocus","style","onKeydown","onKeypress","onKeyup","autosize","status","tips"];function J(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);r&&(n=n.filter(function(p){return Object.getOwnPropertyDescriptor(e,p).enumerable})),t.push.apply(t,n)}return t}function D(e){for(var r=1;r<arguments.length;r++){var t=arguments[r]!=null?arguments[r]:{};r%2?J(Object(t),!0).forEach(function(n){x(e,n,t[n])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):J(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})}return e}var A=c.exports.forwardRef(function(e,r){var t,n,p=e.disabled,v=e.maxlength,s=e.maxcharacter,_=e.className,w=e.readonly,N=e.autofocus,u=e.style,b=e.onKeydown,z=b===void 0?E:b,S=e.onKeypress,T=S===void 0?E:S,y=e.onKeyup,j=y===void 0?E:y,i=e.autosize,h=e.status,g=e.tips,$=ge(e,Se),Q=me(e,"value",e.onChange),F=H(Q,2),L=F[0],f=L===void 0?"":L,ee=F[1],te=c.exports.useState(!1),M=H(te,2),re=M[0],B=M[1],ae=c.exports.useState({}),I=H(ae,2),oe=I[0],C=I[1],U=typeof s!="undefined",O=c.exports.useRef(),V=c.exports.useRef(),ne=c.exports.useMemo(function(){return f?String(f).length:0},[f]),ie=c.exports.useMemo(function(){var a=X(String(f),s);return P(a)==="object"?a.length:a},[f,s]),se=_e(),l=se.classPrefix,le=Object.keys($).filter(function(a){return!/^on[A-Z]/.test(a)}),ce=le.reduce(function(a,o){return Object.assign(a,x({},o,e[o]))},{}),de=Object.keys($).filter(function(a){return/^on[A-Z]/.test(a)}),ue=de.reduce(function(a,o){return Object.assign(a,x({},o,function(m){p||(o==="onFocus"&&B(!0),o==="onBlur"&&B(!1),e[o](m.currentTarget.value,{e:m}))})),a},{}),xe=k(_,"".concat(l,"-textarea__inner"),(t={},x(t,"".concat(l,"-is-").concat(h),h),x(t,"".concat(l,"-is-disabled"),p),x(t,"".concat(l,"-is-focused"),re),x(t,"".concat(l,"-resize-none"),P(i)==="object"),t)),R=c.exports.useCallback(function(){i===!0?C(Y(O.current)):P(i)==="object"&&C(Y(O.current,i==null?void 0:i.minRows,i==null?void 0:i.maxRows))},[i]);function pe(a){var o=a.target,m=o.value;if(s&&s>=0){var W=X(m,s);m=P(W)==="object"&&W.characters}ee(m,{e:a})}return c.exports.useEffect(function(){i===!1&&C({height:"auto",minHeight:"auto"})},[R,i]),c.exports.useEffect(function(){R()},[R,f]),c.exports.useImperativeHandle(r,function(){return{currentElement:V.current,textareaElement:O.current}}),ye("div",{style:u,ref:V,className:k(_,"".concat(l,"-textarea")),children:[K("textarea",G({},D(D(D({},ce),ue),{},{value:f,style:oe,className:xe,readOnly:w,autoFocus:N,disabled:p,maxLength:v,onChange:pe,onKeyDown:function(o){return z(o.currentTarget.value,{e:o})},onKeyPress:function(o){return T(o.currentTarget.value,{e:o})},onKeyUp:function(o){return j(o.currentTarget.value,{e:o})},ref:O}))),U?K("span",{className:"".concat(l,"-textarea__limit"),children:"".concat(ie,"/").concat(s)}):null,!U&&v?K("span",{className:"".concat(l,"-textarea__limit"),children:"".concat(ne,"/").concat(v)}):null,g?K("div",{className:k("".concat(l,"-textarea__tips"),(n={},x(n,"".concat(l,"-textarea__tips--normal"),!h),x(n,"".concat(l,"-textarea__tips--").concat(h),h),n)),children:g}):null]})});A.displayName="Textarea";A.defaultProps=ze;/**
 * tdesign v0.34.4
 * (c) 2022 tdesign
 * @license MIT
 */var Pe=A;export{Pe as T};
