import{R as o,j as r}from"./index.03bc2e41.js";import{E as a}from"./index.7dcb2315.js";const e=()=>r(a,{code:403});var s=o.memo(e);export{s as default};
