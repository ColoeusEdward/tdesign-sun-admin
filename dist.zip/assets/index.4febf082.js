import{R as o,j as r}from"./index.bf91dbec.js";import{E as a}from"./index.cfb1cfed.js";const e=()=>r(a,{code:403});var s=o.memo(e);export{s as default};
