import{R as r,j as o}from"./index.bf91dbec.js";import{E as e}from"./index.cfb1cfed.js";const a=()=>o(e,{code:500});var t=r.memo(a);export{t as default};
